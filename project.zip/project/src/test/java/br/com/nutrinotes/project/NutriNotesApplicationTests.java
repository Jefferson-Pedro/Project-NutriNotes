package br.com.nutrinotes.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutriNotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
